﻿namespace ConsoleUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtWord = new System.Windows.Forms.TextBox();
            this.txtChar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnEnter2 = new System.Windows.Forms.Button();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.btnExit2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtWord
            // 
            this.txtWord.Location = new System.Drawing.Point(175, 135);
            this.txtWord.Name = "txtWord";
            this.txtWord.Size = new System.Drawing.Size(193, 20);
            this.txtWord.TabIndex = 0;
            // 
            // txtChar
            // 
            this.txtChar.Location = new System.Drawing.Point(175, 189);
            this.txtChar.Name = "txtChar";
            this.txtChar.Size = new System.Drawing.Size(193, 20);
            this.txtChar.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(103, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Input Word: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Most Frequent Chatrracter: ";
            // 
            // btnEnter2
            // 
            this.btnEnter2.Location = new System.Drawing.Point(59, 242);
            this.btnEnter2.Name = "btnEnter2";
            this.btnEnter2.Size = new System.Drawing.Size(75, 23);
            this.btnEnter2.TabIndex = 4;
            this.btnEnter2.Text = "Enter";
            this.btnEnter2.UseVisualStyleBackColor = true;
            this.btnEnter2.Click += new System.EventHandler(this.btnEnter2_Click_1);
            // 
            // btnClear2
            // 
            this.btnClear2.Location = new System.Drawing.Point(175, 242);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(75, 23);
            this.btnClear2.TabIndex = 5;
            this.btnClear2.Text = "Clear";
            this.btnClear2.UseVisualStyleBackColor = true;
            this.btnClear2.Click += new System.EventHandler(this.btnClear2_Click);
            // 
            // btnExit2
            // 
            this.btnExit2.Location = new System.Drawing.Point(293, 242);
            this.btnExit2.Name = "btnExit2";
            this.btnExit2.Size = new System.Drawing.Size(75, 23);
            this.btnExit2.TabIndex = 6;
            this.btnExit2.Text = "Exit";
            this.btnExit2.UseVisualStyleBackColor = true;
            this.btnExit2.Click += new System.EventHandler(this.btnExit2_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(446, 338);
            this.Controls.Add(this.btnExit2);
            this.Controls.Add(this.btnClear2);
            this.Controls.Add(this.btnEnter2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtChar);
            this.Controls.Add(this.txtWord);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtString;
        private System.Windows.Forms.TextBox txtFrequentChar;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtWord;
        private System.Windows.Forms.TextBox txtChar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEnter2;
        private System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.Button btnExit2;
    }
}

