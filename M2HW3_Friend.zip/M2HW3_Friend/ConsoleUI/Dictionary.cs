﻿using System;

namespace ConsoleUI
{
    internal class Dictionary
    {
        internal bool Containskey(char v)
        {
            throw new NotImplementedException();
        }
    }
}