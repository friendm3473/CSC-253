﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 9/21/2021
* CSC 253
* Mateo Friend
* Most Frequent Character
*/



namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter2_Click_1(object sender, EventArgs e)
        {
            int[] count = new int[256];

            /* get input word from text box and assign to word */
            String word = txtWord.Text;

            /*length of the string */
            int len = word.Length;

            /* Construct character count array from the input
               string.*/
            for (int i = 0; i < len; i++)
                count[word[i]]++;

            /* initialize the max with first character count */
            int max = count[word[0]];  // Initialize max count
            int pos = 0;   // to store freq character position

            for (int i = 1; i < len; i++)
            {
                if (count[word[i]] > max)
                {
                    max = count[word[i]];
                    pos = i;
                }
            }
            //get the charcter available at position pos
            var s = word[pos];
            /*display the frequent character in text box */
            txtChar.Text = s.ToString();

        }
        // btn for clearing the textboxes
        private void btnClear2_Click(object sender, EventArgs e)
        {
            txtChar.Clear();
            txtWord.Clear();
        }
        // btn to exit the application
        private void btnExit2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}


