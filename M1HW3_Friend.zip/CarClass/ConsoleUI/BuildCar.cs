﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLibrary;
/**
* 8/31/20201
* CSC 253
* mateo friend
* CAR CLASS
*/
namespace ConsoleUI
{
    public class BuildCar
    {
        public static void BuildACar(Car inputCar)
        {
            Console.Write("What is the year of the Car? => ");
            inputCar.Year = Console.ReadLine();

            Console.Write("What is the make of the car? => ");
            inputCar.Make = Console.ReadLine();
        }
    }
}
