﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 8/31/20201
* CSC 253
* mateo friend
* CAR CLASS
*/
namespace CarClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "1. Create car\n2. Acceleraate\n3. Brake\n4. Exit";
        }
        public static string ShowChoiceError()
        {
            return "Not a valid Choice!";
        }
    }
}
