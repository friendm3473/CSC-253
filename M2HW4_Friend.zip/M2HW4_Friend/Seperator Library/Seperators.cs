﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 9/21/2021
* CSC 253
* Mateo Friend
* Word Separator
*/

namespace Seperator_Library
{
    public class Seperators
    {
        public string SentenceSeperator(string str)
        {
            string strWordSplitter = string.Empty;
            string[] arrSentence = str.Split('.');

            foreach (string strWord in arrSentence)
            {
                string sentence = WordSeperator(strWord);
                strWordSplitter = strWordSplitter + sentence + ".";
            }
            return strWordSplitter;
        }

        public string WordSeperator(string strWord)
        {
            string strWordSplitter = string.Empty;

            for (int i = 0; i < strWord.Length; i++)
            {
                if (i == 0)
                {
                    strWordSplitter = strWordSplitter + char.ToUpper(strWord[i]).ToString();
                }
                else
                {
                    if (char.IsUpper(strWord[i]))
                    {
                        strWordSplitter = strWordSplitter + " " + char.ToLower(strWord[i]).ToString();
                    }
                    else
                    {
                        strWordSplitter = strWordSplitter + strWord[i].ToString();
                    }
                }
            }
            return strWordSplitter;
        }
    }
}
