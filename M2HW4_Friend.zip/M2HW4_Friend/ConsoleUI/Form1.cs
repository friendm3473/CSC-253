﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Seperator_Library;

/**
* 9/21/2021
* CSC 253
* Mateo Friend
* Word Separator
*/

namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text.Trim();
            textBox2.Text = SentenceSeperator(str);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private string SentenceSeperator(string str)
        {
            string strWordSplitter = string.Empty;
            string[] arrSentence = str.Split('.');

            foreach (string strWord in arrSentence)
            {
                string sentence = WordSeperator(strWord);
                strWordSplitter = strWordSplitter + sentence + ".";
            }
            return strWordSplitter;
        }

        private string WordSeperator(string strWord)
        {
            string strWordSplitter = string.Empty;

            for (int i = 0; i < strWord.Length; i++)
            {
                if (i == 0)
                {
                    strWordSplitter = strWordSplitter + char.ToUpper(strWord[i]).ToString();
                }
                else
                {
                    if (char.IsUpper(strWord[i]))
                    {
                        strWordSplitter = strWordSplitter + " " + char.ToLower(strWord[i]).ToString();
                    }
                    else
                    {
                        strWordSplitter = strWordSplitter + strWord[i].ToString();
                    }
                } 
            }
            return strWordSplitter;
        }
    }
}
