﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 8/31/2021
* CSC 253
* Mateo Friend
* Celsius to Fahrenheit
*/
namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            // vairables
            double celsius = 0.0;
            double fahrenheit = 0.0;
            lstCelsiusToFahrenheit.Items.Clear();

            while (celsius <= 20)
            {
                fahrenheit = (9 * celsius / 5) + 32;
                lstCelsiusToFahrenheit.Items.Add(celsius.ToString() + "celsius is equal to " + fahrenheit.ToString() + " fahrenheit");
                celsius++;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstCelsiusToFahrenheit.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
