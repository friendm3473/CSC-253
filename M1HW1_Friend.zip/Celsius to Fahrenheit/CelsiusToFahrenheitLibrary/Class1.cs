﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 8/31/2021
* CSC 253
* Mateo Friend
* Celsius to Fahrenheit
*/
namespace CelsiusToFahrenheitLibrary
{
    public class Class1
    {
    }
}
