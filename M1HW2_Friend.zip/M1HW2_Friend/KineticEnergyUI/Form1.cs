﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 8/31/2021
* CSC 253
* Mateo Friend
* Kinetic Energy
*/
namespace KineticEnergyUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private double kineticEnergy(double m, double v)
        {
            double KE = 0.5 * m * Math.Pow(v, 2);
            return KE;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double m;
            double v;

            if (double.TryParse(textBoxMass.Text, out m) && double.TryParse(textBoxVelocity.Text, out v))
            {
                double KE = kineticEnergy(m, v);
                textBoxKinetic.Text = KE.ToString("n");
            }
            else
                MessageBox.Show("Please enter valid numbers", "invalid Input");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBoxKinetic.Clear();
            textBoxMass.Clear();
            textBoxVelocity.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
