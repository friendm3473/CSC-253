﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleLibrary
{
    public class Class1
    {       /**
* 9/21/2021
* CSC 253
* Mateo Friend
* Random Number File Writer
*/
    }
}
