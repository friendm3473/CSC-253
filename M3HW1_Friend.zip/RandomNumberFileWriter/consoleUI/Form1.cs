﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 9/21/2021
* CSC 253
* Mateo Friend
* Random Number File Writer
*/

namespace consoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int randomNumber = 0;
            int number = Convert.ToInt32(txtNumber.Text.Trim());

            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.ShowDialog();
            string filePath = saveFile.FileName;

            StreamWriter outputFile = File.CreateText(filePath);

            while(number > 0)
            {
                randomNumber = random.Next(1, 100);
                outputFile.WriteLine(randomNumber.ToString());
                number--;
            }
            outputFile.Close();
            MessageBox.Show("File Saved in the path " + filePath);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }
    }
}
