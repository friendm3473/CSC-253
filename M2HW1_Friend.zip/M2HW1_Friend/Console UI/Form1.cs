﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Console_UI
{

    /**
        * 9/21/2021
        * CSC 253
        * Mateo Friend
        * Word Counter
        */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string words = textBox1.Text.Trim();
            MessageBox.Show("Number of Words: " + CountWords(words));
        }

        private int CountWords(string words)
        {
            string[] allWords = words.Split(' ');
            return allWords.Length;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
