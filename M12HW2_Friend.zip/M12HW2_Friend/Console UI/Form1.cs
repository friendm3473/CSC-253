﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Console_UI
{

    /**
        * 9/21/2021
        * CSC 253
        * Mateo Friend
        * AVERAGE NUMBER OF LETTERS
        */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;

            if (str.Trim() == "")
            {
                MessageBox.Show("Please enter the String to Display Number of words");
                return;
            }

            int avgNoOfWords = StringWordsCount(str);
            MessageBox.Show("Average number of letters in each word for the given string is: " + avgNoOfWords.ToString());
            }

        private int StringWordsCount(string str)
        {
            int wordsCount = 0;
            int stringLetterCount = 0;
            int avgCount = 0;
            stringLetterCount = str.Length;
            string[] strWords = str.Split(null);
            wordsCount = strWords.Length;
            avgCount = stringLetterCount / wordsCount;
            return avgCount;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
