﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 9/21/2021
* CSC 253
* Mateo Friend
* Random Number File Reader
*/

namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            int count = 0;
            int numbers = 0;
            int totalNumbers = 0;

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            string filePath = openFileDialog.FileName;
            StreamReader inputFile = new StreamReader(filePath);
            lstNumbers.Items.Clear();

            while (!inputFile.EndOfStream)
            {
                numbers = Convert.ToInt32(inputFile.ReadLine());
                totalNumbers = totalNumbers + numbers;
                lstNumbers.Items.Add(numbers.ToString());
                count++;
            }

            txtTotal.Text = totalNumbers.ToString();
            txtRandom.Text = count.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtRandom.Clear();
            txtTotal.Clear();
            lstNumbers.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
