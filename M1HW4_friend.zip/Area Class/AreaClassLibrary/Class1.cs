﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 8/31/2021
* CSC 253
* Mateo Friend
* get the area from user inputs
*/

namespace AreaClassLibrary
{
    public class Class1
    {
    }
}
