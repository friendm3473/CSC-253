﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 8/31/2021
* CSC 253
* Mateo Friend
* get the area from user inputs
*/
namespace ConsoleUI
{
    class Area
    {
        public static double getArea(double r)
        {
            return Math.PI * r * r;
        }

        public static double getArea(double w, double l)
        {
            return w * l;
        }

        public static double getArea(double r, double h, bool isCy)
        {
            if (isCy)
            {
                return Math.PI * r * r * h;
            }
            return 0;
        }
    }
}
