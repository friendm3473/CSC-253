﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 8/31/2021
* CSC 253
* Mateo Friend
* get the area from user inputs
*/
namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            circleGroupBox.Enabled = false;
            rectangleGroupBox.Enabled = false;
            cylinderGroupBox.Enabled = false;
        }

        private void circleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (circleRadioButton.Checked)
            {
                circleGroupBox.Enabled = true;
                rectangleGroupBox.Enabled = false;
                cylinderGroupBox.Enabled = false;
            }
        }

        private void rectangleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (rectangleRadioButton.Checked)
            {
                circleGroupBox.Enabled = false;
                rectangleGroupBox.Enabled = true;
                cylinderGroupBox.Enabled = false;
            }
        }

        private void cylinderRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (cylinderRadioButton.Checked)
            {
                circleGroupBox.Enabled = false;
                rectangleGroupBox.Enabled = false;
                cylinderGroupBox.Enabled = true;
            }
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            double radius = Convert.ToDouble(radiusTextbox.Text);
            double area = Area.getArea(radius);
            MessageBox.Show("Area of circle: " + area.ToString());
        }

        private void btnClearCirc_Click(object sender, EventArgs e)
        {
            radiusTextbox.Text = "";
        }

        private void rectangleButton_Click(object sender, EventArgs e)
        {
            double length = Convert.ToDouble(lengthTextbox.Text);
            double width = Convert.ToDouble(widthTextbox.Text);
            double area = Area.getArea(width, length);
            MessageBox.Show("Area of rectangle: " + area.ToString());
        }

        private void btnClearRect_Click(object sender, EventArgs e)
        {
            lengthTextbox.Text = "";
            widthTextbox.Text = "";
        }

        private void cylinderButton_Click(object sender, EventArgs e)
        {
            double radius = Convert.ToDouble(cyRadiusTextbox.Text);
            double height = Convert.ToDouble(cyHeightTextbox.Text);
            double area = Area.getArea(radius,height,true);
            MessageBox.Show("Area of cylinder: " + area.ToString());
        }

        private void btnClearCyl_Click(object sender, EventArgs e)
        {
            cyRadiusTextbox.Text = "";
            cyHeightTextbox.Text = "";
        }

        private void btnEXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
