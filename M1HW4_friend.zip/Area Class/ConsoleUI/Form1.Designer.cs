﻿namespace ConsoleUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.circleRadioButton = new System.Windows.Forms.RadioButton();
            this.rectangleRadioButton = new System.Windows.Forms.RadioButton();
            this.cylinderRadioButton = new System.Windows.Forms.RadioButton();
            this.radiusLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.cyRadiusLabel = new System.Windows.Forms.Label();
            this.cyHeightLabel = new System.Windows.Forms.Label();
            this.radiusTextbox = new System.Windows.Forms.TextBox();
            this.widthTextbox = new System.Windows.Forms.TextBox();
            this.lengthTextbox = new System.Windows.Forms.TextBox();
            this.cyRadiusTextbox = new System.Windows.Forms.TextBox();
            this.cyHeightTextbox = new System.Windows.Forms.TextBox();
            this.circleButton = new System.Windows.Forms.Button();
            this.btnClearCirc = new System.Windows.Forms.Button();
            this.rectangleButton = new System.Windows.Forms.Button();
            this.btnClearRect = new System.Windows.Forms.Button();
            this.cylinderButton = new System.Windows.Forms.Button();
            this.btnClearCyl = new System.Windows.Forms.Button();
            this.btnEXIT = new System.Windows.Forms.Button();
            this.circleGroupBox = new System.Windows.Forms.GroupBox();
            this.rectangleGroupBox = new System.Windows.Forms.GroupBox();
            this.cylinderGroupBox = new System.Windows.Forms.GroupBox();
            this.circleGroupBox.SuspendLayout();
            this.rectangleGroupBox.SuspendLayout();
            this.cylinderGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // circleRadioButton
            // 
            this.circleRadioButton.AutoSize = true;
            this.circleRadioButton.Location = new System.Drawing.Point(74, 74);
            this.circleRadioButton.Name = "circleRadioButton";
            this.circleRadioButton.Size = new System.Drawing.Size(88, 17);
            this.circleRadioButton.TabIndex = 0;
            this.circleRadioButton.TabStop = true;
            this.circleRadioButton.Text = "Area of Circle";
            this.circleRadioButton.UseVisualStyleBackColor = true;
            this.circleRadioButton.CheckedChanged += new System.EventHandler(this.circleRadioButton_CheckedChanged);
            // 
            // rectangleRadioButton
            // 
            this.rectangleRadioButton.AutoSize = true;
            this.rectangleRadioButton.Location = new System.Drawing.Point(323, 74);
            this.rectangleRadioButton.Name = "rectangleRadioButton";
            this.rectangleRadioButton.Size = new System.Drawing.Size(111, 17);
            this.rectangleRadioButton.TabIndex = 1;
            this.rectangleRadioButton.TabStop = true;
            this.rectangleRadioButton.Text = "Area of Rectangle";
            this.rectangleRadioButton.UseVisualStyleBackColor = true;
            this.rectangleRadioButton.CheckedChanged += new System.EventHandler(this.rectangleRadioButton_CheckedChanged);
            // 
            // cylinderRadioButton
            // 
            this.cylinderRadioButton.AutoSize = true;
            this.cylinderRadioButton.Location = new System.Drawing.Point(576, 74);
            this.cylinderRadioButton.Name = "cylinderRadioButton";
            this.cylinderRadioButton.Size = new System.Drawing.Size(99, 17);
            this.cylinderRadioButton.TabIndex = 2;
            this.cylinderRadioButton.TabStop = true;
            this.cylinderRadioButton.Text = "Area of Cylinder";
            this.cylinderRadioButton.UseVisualStyleBackColor = true;
            this.cylinderRadioButton.CheckedChanged += new System.EventHandler(this.cylinderRadioButton_CheckedChanged);
            // 
            // radiusLabel
            // 
            this.radiusLabel.AutoSize = true;
            this.radiusLabel.Location = new System.Drawing.Point(21, 83);
            this.radiusLabel.Name = "radiusLabel";
            this.radiusLabel.Size = new System.Drawing.Size(66, 13);
            this.radiusLabel.TabIndex = 3;
            this.radiusLabel.Text = "Enter radius:";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Location = new System.Drawing.Point(30, 83);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(63, 13);
            this.widthLabel.TabIndex = 4;
            this.widthLabel.Text = "Enter width:";
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(30, 141);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(67, 13);
            this.lengthLabel.TabIndex = 5;
            this.lengthLabel.Text = "Enter length:";
            // 
            // cyRadiusLabel
            // 
            this.cyRadiusLabel.AutoSize = true;
            this.cyRadiusLabel.Location = new System.Drawing.Point(31, 83);
            this.cyRadiusLabel.Name = "cyRadiusLabel";
            this.cyRadiusLabel.Size = new System.Drawing.Size(66, 13);
            this.cyRadiusLabel.TabIndex = 6;
            this.cyRadiusLabel.Text = "Enter radius:";
            // 
            // cyHeightLabel
            // 
            this.cyHeightLabel.AutoSize = true;
            this.cyHeightLabel.Location = new System.Drawing.Point(31, 141);
            this.cyHeightLabel.Name = "cyHeightLabel";
            this.cyHeightLabel.Size = new System.Drawing.Size(67, 13);
            this.cyHeightLabel.TabIndex = 7;
            this.cyHeightLabel.Text = "Enter height:";
            // 
            // radiusTextbox
            // 
            this.radiusTextbox.Location = new System.Drawing.Point(97, 80);
            this.radiusTextbox.Name = "radiusTextbox";
            this.radiusTextbox.Size = new System.Drawing.Size(100, 20);
            this.radiusTextbox.TabIndex = 8;
            // 
            // widthTextbox
            // 
            this.widthTextbox.Location = new System.Drawing.Point(110, 80);
            this.widthTextbox.Name = "widthTextbox";
            this.widthTextbox.Size = new System.Drawing.Size(100, 20);
            this.widthTextbox.TabIndex = 9;
            // 
            // lengthTextbox
            // 
            this.lengthTextbox.Location = new System.Drawing.Point(110, 138);
            this.lengthTextbox.Name = "lengthTextbox";
            this.lengthTextbox.Size = new System.Drawing.Size(100, 20);
            this.lengthTextbox.TabIndex = 10;
            // 
            // cyRadiusTextbox
            // 
            this.cyRadiusTextbox.Location = new System.Drawing.Point(106, 80);
            this.cyRadiusTextbox.Name = "cyRadiusTextbox";
            this.cyRadiusTextbox.Size = new System.Drawing.Size(100, 20);
            this.cyRadiusTextbox.TabIndex = 11;
            // 
            // cyHeightTextbox
            // 
            this.cyHeightTextbox.Location = new System.Drawing.Point(106, 138);
            this.cyHeightTextbox.Name = "cyHeightTextbox";
            this.cyHeightTextbox.Size = new System.Drawing.Size(100, 20);
            this.cyHeightTextbox.TabIndex = 12;
            // 
            // circleButton
            // 
            this.circleButton.Location = new System.Drawing.Point(24, 216);
            this.circleButton.Name = "circleButton";
            this.circleButton.Size = new System.Drawing.Size(92, 23);
            this.circleButton.TabIndex = 13;
            this.circleButton.Text = "Calculate Area";
            this.circleButton.UseVisualStyleBackColor = true;
            this.circleButton.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // btnClearCirc
            // 
            this.btnClearCirc.Location = new System.Drawing.Point(122, 216);
            this.btnClearCirc.Name = "btnClearCirc";
            this.btnClearCirc.Size = new System.Drawing.Size(75, 23);
            this.btnClearCirc.TabIndex = 14;
            this.btnClearCirc.Text = "Clear";
            this.btnClearCirc.UseVisualStyleBackColor = true;
            this.btnClearCirc.Click += new System.EventHandler(this.btnClearCirc_Click);
            // 
            // rectangleButton
            // 
            this.rectangleButton.Location = new System.Drawing.Point(33, 216);
            this.rectangleButton.Name = "rectangleButton";
            this.rectangleButton.Size = new System.Drawing.Size(96, 23);
            this.rectangleButton.TabIndex = 15;
            this.rectangleButton.Text = "Calculate Area";
            this.rectangleButton.UseVisualStyleBackColor = true;
            this.rectangleButton.Click += new System.EventHandler(this.rectangleButton_Click);
            // 
            // btnClearRect
            // 
            this.btnClearRect.Location = new System.Drawing.Point(135, 216);
            this.btnClearRect.Name = "btnClearRect";
            this.btnClearRect.Size = new System.Drawing.Size(75, 23);
            this.btnClearRect.TabIndex = 16;
            this.btnClearRect.Text = "Clear";
            this.btnClearRect.UseVisualStyleBackColor = true;
            this.btnClearRect.Click += new System.EventHandler(this.btnClearRect_Click);
            // 
            // cylinderButton
            // 
            this.cylinderButton.Location = new System.Drawing.Point(34, 216);
            this.cylinderButton.Name = "cylinderButton";
            this.cylinderButton.Size = new System.Drawing.Size(91, 23);
            this.cylinderButton.TabIndex = 17;
            this.cylinderButton.Text = "Calculate Area";
            this.cylinderButton.UseVisualStyleBackColor = true;
            this.cylinderButton.Click += new System.EventHandler(this.cylinderButton_Click);
            // 
            // btnClearCyl
            // 
            this.btnClearCyl.Location = new System.Drawing.Point(131, 216);
            this.btnClearCyl.Name = "btnClearCyl";
            this.btnClearCyl.Size = new System.Drawing.Size(75, 23);
            this.btnClearCyl.TabIndex = 18;
            this.btnClearCyl.Text = "Clear";
            this.btnClearCyl.UseVisualStyleBackColor = true;
            this.btnClearCyl.Click += new System.EventHandler(this.btnClearCyl_Click);
            // 
            // btnEXIT
            // 
            this.btnEXIT.Location = new System.Drawing.Point(675, 418);
            this.btnEXIT.Name = "btnEXIT";
            this.btnEXIT.Size = new System.Drawing.Size(75, 23);
            this.btnEXIT.TabIndex = 19;
            this.btnEXIT.Text = "EXIT";
            this.btnEXIT.UseVisualStyleBackColor = true;
            this.btnEXIT.Click += new System.EventHandler(this.btnEXIT_Click);
            // 
            // circleGroupBox
            // 
            this.circleGroupBox.Controls.Add(this.btnClearCirc);
            this.circleGroupBox.Controls.Add(this.circleButton);
            this.circleGroupBox.Controls.Add(this.radiusLabel);
            this.circleGroupBox.Controls.Add(this.radiusTextbox);
            this.circleGroupBox.Location = new System.Drawing.Point(12, 124);
            this.circleGroupBox.Name = "circleGroupBox";
            this.circleGroupBox.Size = new System.Drawing.Size(237, 286);
            this.circleGroupBox.TabIndex = 20;
            this.circleGroupBox.TabStop = false;
            this.circleGroupBox.Text = "Circle";
            // 
            // rectangleGroupBox
            // 
            this.rectangleGroupBox.Controls.Add(this.btnClearRect);
            this.rectangleGroupBox.Controls.Add(this.rectangleButton);
            this.rectangleGroupBox.Controls.Add(this.lengthLabel);
            this.rectangleGroupBox.Controls.Add(this.widthLabel);
            this.rectangleGroupBox.Controls.Add(this.widthTextbox);
            this.rectangleGroupBox.Controls.Add(this.lengthTextbox);
            this.rectangleGroupBox.Location = new System.Drawing.Point(255, 124);
            this.rectangleGroupBox.Name = "rectangleGroupBox";
            this.rectangleGroupBox.Size = new System.Drawing.Size(250, 286);
            this.rectangleGroupBox.TabIndex = 0;
            this.rectangleGroupBox.TabStop = false;
            this.rectangleGroupBox.Text = "Rectangle";
            // 
            // cylinderGroupBox
            // 
            this.cylinderGroupBox.Controls.Add(this.btnClearCyl);
            this.cylinderGroupBox.Controls.Add(this.cylinderButton);
            this.cylinderGroupBox.Controls.Add(this.cyHeightLabel);
            this.cylinderGroupBox.Controls.Add(this.cyRadiusLabel);
            this.cylinderGroupBox.Controls.Add(this.cyHeightTextbox);
            this.cylinderGroupBox.Controls.Add(this.cyRadiusTextbox);
            this.cylinderGroupBox.Location = new System.Drawing.Point(516, 124);
            this.cylinderGroupBox.Name = "cylinderGroupBox";
            this.cylinderGroupBox.Size = new System.Drawing.Size(234, 286);
            this.cylinderGroupBox.TabIndex = 0;
            this.cylinderGroupBox.TabStop = false;
            this.cylinderGroupBox.Text = "Cylinder";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rectangleGroupBox);
            this.Controls.Add(this.cylinderGroupBox);
            this.Controls.Add(this.circleGroupBox);
            this.Controls.Add(this.btnEXIT);
            this.Controls.Add(this.cylinderRadioButton);
            this.Controls.Add(this.rectangleRadioButton);
            this.Controls.Add(this.circleRadioButton);
            this.Name = "Form1";
            this.Text = "Area";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.circleGroupBox.ResumeLayout(false);
            this.circleGroupBox.PerformLayout();
            this.rectangleGroupBox.ResumeLayout(false);
            this.rectangleGroupBox.PerformLayout();
            this.cylinderGroupBox.ResumeLayout(false);
            this.cylinderGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton circleRadioButton;
        private System.Windows.Forms.RadioButton rectangleRadioButton;
        private System.Windows.Forms.RadioButton cylinderRadioButton;
        private System.Windows.Forms.Label radiusLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label cyRadiusLabel;
        private System.Windows.Forms.Label cyHeightLabel;
        private System.Windows.Forms.TextBox radiusTextbox;
        private System.Windows.Forms.TextBox widthTextbox;
        private System.Windows.Forms.TextBox lengthTextbox;
        private System.Windows.Forms.TextBox cyRadiusTextbox;
        private System.Windows.Forms.TextBox cyHeightTextbox;
        private System.Windows.Forms.Button circleButton;
        private System.Windows.Forms.Button btnClearCirc;
        private System.Windows.Forms.Button rectangleButton;
        private System.Windows.Forms.Button btnClearRect;
        private System.Windows.Forms.Button cylinderButton;
        private System.Windows.Forms.Button btnClearCyl;
        private System.Windows.Forms.Button btnEXIT;
        private System.Windows.Forms.GroupBox circleGroupBox;
        private System.Windows.Forms.GroupBox rectangleGroupBox;
        private System.Windows.Forms.GroupBox cylinderGroupBox;
    }
}

