﻿CREATE TABLE [dbo].[City] (
    [City]       NVARCHAR (50) NOT NULL,
    [Population] INT    NULL,
    CONSTRAINT [PK_City] PRIMARY KEY CLUSTERED ([City] ASC)
);

