﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PopulationLibrary;

/**
* 10/10/2021
* CSC 253
* Mateo Friend
* Population Database
*/

namespace WinsUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void cityBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void btnSortpopAsc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Ascending(this.populationDBDataSet.City);
        }

        private void btnSortPopDescending_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Descending(this.populationDBDataSet.City);
        }


        private void btnGetTotal_Click(object sender, EventArgs e)
        {
            int totalPopulation;
            totalPopulation = (int)this.cityTableAdapter.Total();
            MessageBox.Show(totalPopulation.ToString());
        }

        private void btnGetAverage_Click(object sender, EventArgs e)
        {
            int averagePopulation;
            averagePopulation = (int)this.cityTableAdapter.Average();
            MessageBox.Show(averagePopulation.ToString());
        }

        private void btnGetHighestPop_Click(object sender, EventArgs e)
        {
            int maxPopulation;
            maxPopulation = (int)this.cityTableAdapter.Maximum();
            MessageBox.Show(maxPopulation.ToString());

        }

        private void BtnGetLowPop_Click(object sender, EventArgs e)
        {
            int minPopulation;
            minPopulation = (int)this.cityTableAdapter.Minimum();
            MessageBox.Show(minPopulation.ToString());
        }

        private void btnSortByName_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.Cities(this.populationDBDataSet.City);
        }
    }
}
