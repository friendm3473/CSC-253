﻿namespace WinsUI
{


    partial class PopulationDBDataSet
    {
    }
}

namespace WinsUI.PopulationDBDataSetTableAdapters {
    
    
    public partial class CityTableAdapter {
    }
}
