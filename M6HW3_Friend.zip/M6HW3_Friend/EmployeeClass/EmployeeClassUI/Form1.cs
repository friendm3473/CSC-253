﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

        /**
        * 11/22/2021
        * CSC 253
        * Mateo Friend
        * Employee Class
        */

namespace EmployeeClassUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Employee number1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
        private Employee number2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
        private Employee number3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            textEmp1.Text = number1.Name + ", " + number1.IdNumber + ", " + number1.Department + ", " + number1.Position;
            textEmp2.Text = number2.Name + ", " + number2.IdNumber + ", " + number2.Department + ", " + number2.Position;
            textEmp3.Text = number3.Name + ", " + number3.IdNumber + ", " + number3.Department + ", " + number3.Position;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
