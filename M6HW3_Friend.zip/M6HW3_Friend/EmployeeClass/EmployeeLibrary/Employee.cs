﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

        /**
        * 11/22/2021
        * CSC 253
        * Mateo Friend
        * Employee Class
        */

namespace EmployeeLibrary
{
    public class Employee
    {
        private string _name;
        private decimal _idNumber;
        private string _department;
        private string _position;

        public Employee()
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";
        }

        public Employee(string name, decimal idNumber, string department, string position)
        {
            _name = name;
            _idNumber = idNumber;
            _department = department;
            _position = position;
        }

        public Employee(string name, decimal idNumber)
        {
            _name = name;
            _idNumber = idNumber;
            _department = "";
            _position = "";
        }
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }
        public decimal IdNumber
        {
            set { _idNumber = value; }
            get { return _idNumber; }
        }
        public string Department
        {
            set { _department = value; }
            get { return _department; }
        }
        public string Position
        {
            set { _position = value; }
            get { return _position; }
        }
    }

}
